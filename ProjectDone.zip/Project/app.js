'use strict'
var express = require('express');
var bodyParser = require('body-parser');
var fs = require('fs');
var app = express();
var path = require('path');
var session = require('express-session');
var mysql = require('mysql');
var compileRun = require('compile-run')

var con = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "root",
	database: "mydb"
});


//body parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended: true
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
	secret: "Shh, its a secret!",
	resave: true,
	saveUninitialized: true
}));

var dirPath = path.join(__dirname, 'files');

app.get('/signup', (req, res) => {
	res.render('signup')
})

var fileData = [],
	fileHint = [],
	count = 0;

//login page

app.get('/', (req, res) => {

	res.render('login')

})

app.post('/login', (req, res) => {
	req.session.user = req.body.pass
	req.session.rollno = req.body.name
	res.redirect('dashboard')
})


app.get('/signup', (req, res) => {
	res.render('signup')
})
app.post('/createUserFile', (req, res) => {
	console.log(req.body.file)
	var dirPath = path.join(__dirname, 'studentProgress');
	req.session.user = req.body.username
	req.session.rollno = req.body.rollno
	var filename = req.body.rollno
	fs.writeFile(dirPath + "/" + filename + ".json", req.body.file, 'utf8')

	res.send("success")

})

app.get('/dashboard', (req, res) => {
	if (req.session.user && req.session.rollno) {
		let userFilePath = path.join(__dirname, 'studentProgress/' + req.session.rollno + '.json')
		let content = fs.readFileSync(userFilePath, 'utf8')
		let jsonContent;
		try {
			jsonContent = JSON.parse(content)
		} catch (e) {
			console.log(e)
		}
		console.log(jsonContent.name)
		res.render('dashboard', {
			userData: jsonContent
		})
	} else {
		res.redirect('/')
	}
})

// start
app.get('/afterLogin', (req, res) => {
	if (req.session.user && req.session.rollno) {
		var dirs = fs.readdirSync(dirPath)
		var dirName = dirs.filter(f => fs.statSync(path.join(dirPath, f)).isDirectory())
		console.log(dirPath)
		res.render('dumy', {
			topics: dirName
		})
	} else {
		res.redirect('/')
	}
})
app.get('/subjects/:subject', function (req, res) {
	if (req.session.user && req.session.rollno) {

		req.session.subject = req.params.subject
		var sub = "SPA"
		var x = "files/" + sub
		var dirpath = path.join(__dirname, x)
		var files = fs.readdirSync(dirpath);

		files.forEach(function (filename) {
			var filePath = dirpath + '/' + filename;
			fs.readFile(filePath, 'utf8', function (err, data) {
				if (err) {
					console.log(err);
				} else {
					fileData.push(data);
					var first = [];
					first.push(data.split('\n'));
					fileHint.push(first[0][0]);
				}
			});
		});

		var x = []
		x = fileData.sort()
		res.render('index', {
			details: fileData,
			subject: sub
		});

		fileData = [];
		fileHint = [];
	} else {
		res.redirect('/')
	}
});


app.get('/solve/:subject/:filename', function (req, res) {

	if (req.session.user && req.session.rollno) {
		var fullFileName = "files/" + req.params.subject + "/" + req.params.filename + ".txt";
		var pathFinal = path.join(__dirname, fullFileName);
		var dataSend = "";
		fs.readFile(pathFinal, 'utf8', function (err, data) {
			dataSend = "";
			if (err) {
				console.log(err);
			} else {
				dataSend += data;
				res.render("code", {
					file: dataSend,
					name: req.params.filename
				});
			}

		});
	} else {
		res.redirect('/')
	}

});

app.post('/updateUserFile', (req, res) => {
	var name = req.session.rollno
	var fullFileName = "studentProgress/" + name + ".json";
	var pathFinal = path.join(__dirname, fullFileName);
	var dataSend = fs.readFileSync(pathFinal, 'utf8')
	console.log(typeof dataSend)
	var da = JSON.parse(dataSend)
	var num = parseInt(req.body.exptNo[req.body.exptNo.length - 1])
	if (num == 0) {
		num = 10
	}
	var subj = req.body.sub
	da.subjects[subj].Comp[num - 1] = req.body.com
	da.subjects[subj].marks[num - 1] = req.body.marks
	var total = 0
	da.subjects[subj].marks.forEach(item => {
		total = total + parseInt(item)
	})
	da.subjects.SPA.per = total;
	var d = JSON.stringify(da, null, 2)
	fs.writeFile(pathFinal, d, 'utf8')

})

//New
function readInput(expt) {
	console.log(expt)
	var filesInput = path.join(__dirname, 'filesInput/SPA')
	var inputString = fs.readFileSync(filesInput + '/' + expt + 'In.txt', 'utf8')
	return inputString
}

function readOutput(expt) {
	var filesOutput = path.join(__dirname, 'filesOutput/SPA')
	var outputString = fs.readFileSync(filesOutput + '/' + expt + 'Out.txt', 'utf8')
	return outputString
}
app.post('/retrieveInput', function (req, res) {

	let inputStringCopy = readInput(req.body.expt)

	let inputArray = inputStringCopy.split('\n')

	res.send({
		input: inputArray
	})
})
app.post('/retrieveOutput', function (req, res) {

	let outputStringCopy = readOutput(req.body.expt)

	let outputArray = outputStringCopy.split('\n')

	res.send({
		output: outputArray
	})
})
app.post('/compile', (req, res) => {
	var code = req.body.code;
	var input = req.body.input;
	console.log(input)

	compileRun.runCpp(code, input, function (stdout, stderr, err) {
		if (!err) {
			if (stderr == "")
				res.send(stdout)
			else
				res.send(stderr)
		} else
			res.send(err)

	});

})

app.listen(3000);